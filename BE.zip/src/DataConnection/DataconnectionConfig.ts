export const DataConfig = {
    user: 'Minematics',
    password: 'mines@123',
    server: '286-19771',
    database: 'MindMap',
    // options: {
    //   encrypt: true, // For Azure SQL Database
    // },
  };

